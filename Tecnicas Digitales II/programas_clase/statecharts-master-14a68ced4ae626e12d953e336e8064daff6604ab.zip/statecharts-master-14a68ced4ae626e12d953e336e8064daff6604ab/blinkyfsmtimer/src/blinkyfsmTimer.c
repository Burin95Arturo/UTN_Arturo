#include "chip.h"
#include "statechart/src-gen/BlinkyTimerRequired.h"
#include "timers/TimerTicks.h"

#define TICKS_SISTEMA	(1000)
#define LED_PUERTO		(0)
#define LED_PIN			(22)
#define FSM_NTIMERS		(4)

void configurarHardware(void);
void blinkyTimerIface_setearLed(const BlinkyTimer* handle, const sc_boolean estado);
void blinkyTimer_setTimer(BlinkyTimer* handle, const sc_eventid evid, const sc_integer time_ms, const sc_boolean periodic);
void blinkyTimer_unsetTimer(BlinkyTimer* handle, const sc_eventid evid);

BlinkyTimer statechart;
TimerTicks timers[FSM_NTIMERS];

int main(void)
{
	int i;
	InitTimerTicks(timers,FSM_NTIMERS);
	blinkyTimer_init(&statechart);
	blinkyTimer_enter(&statechart);
	configurarHardware();

	while(1)
	{
		UpdateTimers(timers,FSM_NTIMERS);
		for(i=0; i<FSM_NTIMERS; i++)
		{
			if(IsPendEvent(timers,FSM_NTIMERS,timers[i].evid))
			{
				blinkyTimer_raiseTimeEvent(&statechart,timers[i].evid);
				MarkAsAttEvent(timers,FSM_NTIMERS,timers[i].evid);
			}
		}
		blinkyTimer_runCycle(&statechart);
		__WFI();	/*Mando a dormir al procesador*/
    }
    return 0 ;
}

void SysTick_Handler(void)
{
	/* Sólo despierto al micro una vez por milisegundo */
}

void configurarHardware(void)
{
	Chip_SetupXtalClocking();
	SystemCoreClockUpdate();
	Chip_GPIO_Init(LPC_GPIO);
	Chip_IOCON_Init(LPC_IOCON);
	SysTick_Config(SystemCoreClock/TICKS_SISTEMA);
	Chip_IOCON_PinMux(LPC_IOCON,LED_PUERTO,LED_PIN,IOCON_MODE_INACT,IOCON_FUNC0);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO,LED_PUERTO,LED_PIN);
}

void blinkyTimerIface_setearLed(const BlinkyTimer* handle, const sc_boolean estado)
{
	Chip_GPIO_SetPinState(LPC_GPIO,LED_PUERTO,LED_PIN,(estado==true)?1:0);
}

void blinkyTimer_setTimer(BlinkyTimer* handle, const sc_eventid evid, const sc_integer time_ms, const sc_boolean periodic)
{
	SetNewTimerTick(timers,FSM_NTIMERS,evid,time_ms,periodic);
}

void blinkyTimer_unsetTimer(BlinkyTimer* handle, const sc_eventid evid)
{
	UnsetTimerTick(timers,FSM_NTIMERS,evid);
}
