#include "chip.h"
#include "statechart/src-gen/BlinkypulsadorRequired.h"
#include "timers/TimerTicks.h"

#define TICKS_SISTEMA	(1000)
#define LED_PUERTO		(0)
#define LED_PIN			(22)
#define BOTON_PUERTO	(2)
#define BOTON_PIN		(12)
#define FSM_NTIMERS		(4)


void configurarHardware(void);
void blinkypulsadorIface_opSetearLed(const Blinkypulsador* handle, const sc_boolean estado);
void blinkypulsador_setTimer(Blinkypulsador* handle, const sc_eventid evid, const sc_integer time_ms, const sc_boolean periodic);
void blinkypulsador_unsetTimer(Blinkypulsador* handle, const sc_eventid evid);


Blinkypulsador statechart;
TimerTicks timers[FSM_NTIMERS];

int main(void)
{
	int i;
	InitTimerTicks(timers,FSM_NTIMERS);
	blinkypulsador_init(&statechart);
	blinkypulsador_enter(&statechart);
	configurarHardware();

	while(1)
	{
		UpdateTimers(timers,FSM_NTIMERS);
		for(i=0; i<FSM_NTIMERS; i++)
		{
			if(IsPendEvent(timers,FSM_NTIMERS,timers[i].evid))
			{
				blinkypulsador_raiseTimeEvent(&statechart,timers[i].evid);
				MarkAsAttEvent(timers,FSM_NTIMERS,timers[i].evid);
			}
		}
		blinkypulsadorIface_set_boton(&statechart,(Chip_GPIO_ReadPortBit(LPC_GPIO,BOTON_PUERTO,BOTON_PIN))?true:false);
		blinkypulsador_runCycle(&statechart);
		__WFI();	/*Mando a dormir al procesador*/
    }
    return 0 ;
}

void SysTick_Handler(void)
{
	/* Sólo despierto al micro una vez por milisegundo */
}

void configurarHardware(void)
{
	Chip_SetupXtalClocking();
	SystemCoreClockUpdate();
	Chip_GPIO_Init(LPC_GPIO);
	Chip_IOCON_Init(LPC_IOCON);
	SysTick_Config(SystemCoreClock/TICKS_SISTEMA);
	Chip_IOCON_PinMux(LPC_IOCON,LED_PUERTO,LED_PIN,IOCON_MODE_INACT,IOCON_FUNC0);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO,LED_PUERTO,LED_PIN);
	Chip_IOCON_PinMux(LPC_IOCON,BOTON_PUERTO,BOTON_PIN,IOCON_MODE_PULLUP,IOCON_FUNC0);
	Chip_GPIO_SetPinDIRInput(LPC_GPIO,BOTON_PUERTO,BOTON_PIN);

}

void blinkypulsadorIface_opSetearLed(const Blinkypulsador* handle, const sc_boolean estado)
{
	Chip_GPIO_SetPinState(LPC_GPIO,LED_PUERTO,LED_PIN,(estado==true)?1:0);
}

void blinkypulsador_setTimer(Blinkypulsador* handle, const sc_eventid evid, const sc_integer time_ms, const sc_boolean periodic)
{
	SetNewTimerTick(timers,FSM_NTIMERS,evid,time_ms,periodic);
}

void blinkypulsador_unsetTimer(Blinkypulsador* handle, const sc_eventid evid)
{
	UnsetTimerTick(timers,FSM_NTIMERS,evid);
}
