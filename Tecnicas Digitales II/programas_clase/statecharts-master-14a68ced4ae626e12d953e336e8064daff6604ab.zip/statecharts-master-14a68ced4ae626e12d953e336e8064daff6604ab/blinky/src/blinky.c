#include "chip.h"
#define TICKS_SISTEMA	(1000)
#define LED_TICKS_MS	(100)
#define LED_PUERTO		(0)
#define LED_PIN			(22)

void configurarHardware(void);


int main(void)
{
	int demora = LED_TICKS_MS;
	configurarHardware();
	while(1)
	{
		if(!--demora)
		{
			demora = LED_TICKS_MS;
			Chip_GPIO_SetPinToggle(LPC_GPIO,LED_PUERTO,LED_PIN);
		}
		__WFI();	/*	Procesador a dormir	*/
    }
    return 0 ;
}

void SysTick_Handler(void)
{
	/*	Saco al procesador de la suspensión	*/
}

void configurarHardware(void)
{
	Chip_SetupXtalClocking();
	SystemCoreClockUpdate();
	Chip_GPIO_Init(LPC_GPIO);
	Chip_IOCON_Init(LPC_IOCON);
	SysTick_Config(SystemCoreClock/TICKS_SISTEMA);
	Chip_IOCON_PinMux(LPC_IOCON,LED_PUERTO,LED_PIN,IOCON_MODE_INACT,IOCON_FUNC0);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO,LED_PUERTO,LED_PIN);
}
