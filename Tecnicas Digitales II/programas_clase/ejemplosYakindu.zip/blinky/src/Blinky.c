
#include <stdlib.h>
#include <string.h>
#include "../fsm/src/sc_types.h"
#include "Blinky.h"
/*! \file Implementation of the state machine 'blinky'
*/

/* prototypes of all internal functions */
static sc_boolean blinky_check_main_region_LedArriba_tr0_tr0(const Blinky* handle);
static sc_boolean blinky_check_main_region_LedAbajo_tr0_tr0(const Blinky* handle);
static void blinky_effect_main_region_LedArriba_tr0(Blinky* handle);
static void blinky_effect_main_region_LedAbajo_tr0(Blinky* handle);
static void blinky_enseq_main_region_LedArriba_default(Blinky* handle);
static void blinky_enseq_main_region_LedAbajo_default(Blinky* handle);
static void blinky_enseq_main_region_default(Blinky* handle);
static void blinky_exseq_main_region_LedArriba(Blinky* handle);
static void blinky_exseq_main_region_LedAbajo(Blinky* handle);
static void blinky_exseq_main_region(Blinky* handle);
static void blinky_react_main_region_LedArriba(Blinky* handle);
static void blinky_react_main_region_LedAbajo(Blinky* handle);
static void blinky_react_main_region__entry_Default(Blinky* handle);
static void blinky_clearInEvents(Blinky* handle);
static void blinky_clearOutEvents(Blinky* handle);


void blinky_init(Blinky* handle)
{
	sc_integer i;

	for (i = 0; i < BLINKY_MAX_ORTHOGONAL_STATES; ++i)
	{
		handle->stateConfVector[i] = Blinky_last_state;
	}
	
	
	handle->stateConfVectorPosition = 0;

	blinky_clearInEvents(handle);
	blinky_clearOutEvents(handle);


}

void blinky_enter(Blinky* handle)
{
	/* Default enter sequence for statechart blinky */
	blinky_enseq_main_region_default(handle);
}

void blinky_exit(Blinky* handle)
{
	/* Default exit sequence for statechart blinky */
	blinky_exseq_main_region(handle);
}

sc_boolean blinky_isActive(const Blinky* handle)
{
	sc_boolean result;
	if (handle->stateConfVector[0] != Blinky_last_state)
	{
		result =  bool_true;
	}
	else
	{
		result = bool_false;
	}
	return result;
}

/* 
 * Always returns 'false' since this state machine can never become final.
 */
sc_boolean blinky_isFinal(const Blinky* handle)
{
   return bool_false;
}

static void blinky_clearInEvents(Blinky* handle)
{
	handle->iface.eCambiar_raised = bool_false;
}

static void blinky_clearOutEvents(Blinky* handle)
{
}

void blinky_runCycle(Blinky* handle)
{
	
	blinky_clearOutEvents(handle);
	
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < BLINKY_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case Blinky_main_region_LedArriba :
		{
			blinky_react_main_region_LedArriba(handle);
			break;
		}
		case Blinky_main_region_LedAbajo :
		{
			blinky_react_main_region_LedAbajo(handle);
			break;
		}
		default:
			break;
		}
	}
	
	blinky_clearInEvents(handle);
}


sc_boolean blinky_isStateActive(const Blinky* handle, BlinkyStates state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case Blinky_main_region_LedArriba :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky_main_region_LedArriba
			);
			break;
		case Blinky_main_region_LedAbajo :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky_main_region_LedAbajo
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}

void blinkyIface_raise_eCambiar(Blinky* handle)
{
	handle->iface.eCambiar_raised = bool_true;
}



/* implementations of all internal functions */

static sc_boolean blinky_check_main_region_LedArriba_tr0_tr0(const Blinky* handle)
{
	return handle->iface.eCambiar_raised;
}

static sc_boolean blinky_check_main_region_LedAbajo_tr0_tr0(const Blinky* handle)
{
	return handle->iface.eCambiar_raised;
}

static void blinky_effect_main_region_LedArriba_tr0(Blinky* handle)
{
	blinky_exseq_main_region_LedArriba(handle);
	blinky_enseq_main_region_LedAbajo_default(handle);
}

static void blinky_effect_main_region_LedAbajo_tr0(Blinky* handle)
{
	blinky_exseq_main_region_LedAbajo(handle);
	blinky_enseq_main_region_LedArriba_default(handle);
}

/* 'default' enter sequence for state LedArriba */
static void blinky_enseq_main_region_LedArriba_default(Blinky* handle)
{
	/* 'default' enter sequence for state LedArriba */
	handle->stateConfVector[0] = Blinky_main_region_LedArriba;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state LedAbajo */
static void blinky_enseq_main_region_LedAbajo_default(Blinky* handle)
{
	/* 'default' enter sequence for state LedAbajo */
	handle->stateConfVector[0] = Blinky_main_region_LedAbajo;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for region main region */
static void blinky_enseq_main_region_default(Blinky* handle)
{
	/* 'default' enter sequence for region main region */
	blinky_react_main_region__entry_Default(handle);
}

/* Default exit sequence for state LedArriba */
static void blinky_exseq_main_region_LedArriba(Blinky* handle)
{
	/* Default exit sequence for state LedArriba */
	handle->stateConfVector[0] = Blinky_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state LedAbajo */
static void blinky_exseq_main_region_LedAbajo(Blinky* handle)
{
	/* Default exit sequence for state LedAbajo */
	handle->stateConfVector[0] = Blinky_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for region main region */
static void blinky_exseq_main_region(Blinky* handle)
{
	/* Default exit sequence for region main region */
	/* Handle exit of all possible states (of blinky.main_region) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Blinky_main_region_LedArriba :
		{
			blinky_exseq_main_region_LedArriba(handle);
			break;
		}
		case Blinky_main_region_LedAbajo :
		{
			blinky_exseq_main_region_LedAbajo(handle);
			break;
		}
		default: break;
	}
}

/* The reactions of state LedArriba. */
static void blinky_react_main_region_LedArriba(Blinky* handle)
{
	/* The reactions of state LedArriba. */
	if (blinky_check_main_region_LedArriba_tr0_tr0(handle) == bool_true)
	{ 
		blinky_effect_main_region_LedArriba_tr0(handle);
	} 
}

/* The reactions of state LedAbajo. */
static void blinky_react_main_region_LedAbajo(Blinky* handle)
{
	/* The reactions of state LedAbajo. */
	if (blinky_check_main_region_LedAbajo_tr0_tr0(handle) == bool_true)
	{ 
		blinky_effect_main_region_LedAbajo_tr0(handle);
	} 
}

/* Default react sequence for initial entry  */
static void blinky_react_main_region__entry_Default(Blinky* handle)
{
	/* Default react sequence for initial entry  */
	blinky_enseq_main_region_LedArriba_default(handle);
}


