#include "main.h"
#include "board.h"
#include "Blinky.h"

#define  NTICS	125

int eventoTics;
Blinky bestado;


static void initHardware(void)
{
	Board_Init();
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock / 1000);
}

int main(void)
{
	eventoTics = 0;
	blinky_init(&bestado);
	blinky_enter(&bestado);
	initHardware();

	while (1)
	{
		if(eventoTics)
		{
			eventoTics=0;
			blinkyIface_raise_eCambiar(&bestado);
			blinky_runCycle(&bestado);
		}
		if(blinky_isStateActive(&bestado,Blinky_main_region_LedArriba))
		{
			Board_LED_Set(0,1);
		}

		if(blinky_isStateActive(&bestado,Blinky_main_region_LedAbajo))
		{
			Board_LED_Set(0,0);
		}

	}
}

void SysTick_Handler(void)
{
	static int tics = NTICS;
	if(!--tics)
	{
		tics=NTICS;
		eventoTics=1;
	}
}
