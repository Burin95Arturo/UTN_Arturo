
#include <stdlib.h>
#include <string.h>
#include "../fsm/src/sc_types.h"
#include "Blinky4.h"
#include "Blinky4Required.h"
/*! \file Implementation of the state machine 'blinky4'
*/

/* prototypes of all internal functions */
static sc_boolean blinky4_check_main_region_Programa_r1_Presionado_tr0_tr0(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r1_Presionado_tr1_tr1(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r1_Espera_tr0_tr0(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r1_Presiona_tr0_tr0(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r1_Presiona_tr1_tr1(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r1_Presiona_tr2_tr2(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_tr0_tr0(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOn_tr0_tr0(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOn_tr1_tr1(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOff_tr0_tr0(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOff_tr1_tr1(const Blinky4* handle);
static sc_boolean blinky4_check_main_region_Programa_r2_No_parpadea_tr0_tr0(const Blinky4* handle);
static void blinky4_effect_main_region_Programa_r1_Presionado_tr0(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r1_Presionado_tr1(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r1_Espera_tr0(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r1_Presiona_tr0(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r1_Presiona_tr1(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r1_Presiona_tr2(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r2_Parpadea_tr0(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOn_tr0(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOn_tr1(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOff_tr0(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOff_tr1(Blinky4* handle);
static void blinky4_effect_main_region_Programa_r2_No_parpadea_tr0(Blinky4* handle);
static void blinky4_enact_main_region_Programa_r2_Parpadea_r1_LedOn(Blinky4* handle);
static void blinky4_enact_main_region_Programa_r2_Parpadea_r1_LedOff(Blinky4* handle);
static void blinky4_enact_main_region_Programa_r2_No_parpadea(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r1_Presionado_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r1_Espera_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r1_Presiona_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r2_Parpadea_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOn_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOff_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r2_No_parpadea_default(Blinky4* handle);
static void blinky4_enseq_main_region_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r1_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r2_default(Blinky4* handle);
static void blinky4_enseq_main_region_Programa_r2_Parpadea_r1_default(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r1_Presionado(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r1_Espera(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r1_Presiona(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r2_Parpadea(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOn(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOff(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r2_No_parpadea(Blinky4* handle);
static void blinky4_exseq_main_region(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r1(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r2(Blinky4* handle);
static void blinky4_exseq_main_region_Programa_r2_Parpadea_r1(Blinky4* handle);
static void blinky4_react_main_region_Programa_r1_Presionado(Blinky4* handle);
static void blinky4_react_main_region_Programa_r1_Espera(Blinky4* handle);
static void blinky4_react_main_region_Programa_r1_Presiona(Blinky4* handle);
static void blinky4_react_main_region_Programa_r2_Parpadea_r1_LedOn(Blinky4* handle);
static void blinky4_react_main_region_Programa_r2_Parpadea_r1_LedOff(Blinky4* handle);
static void blinky4_react_main_region_Programa_r2_No_parpadea(Blinky4* handle);
static void blinky4_react_main_region__entry_Default(Blinky4* handle);
static void blinky4_react_main_region_Programa_r1__entry_Default(Blinky4* handle);
static void blinky4_react_main_region_Programa_r2_Parpadea_r1__entry_Default(Blinky4* handle);
static void blinky4_react_main_region_Programa_r2__entry_Default(Blinky4* handle);
static void blinky4_clearInEvents(Blinky4* handle);
static void blinky4_clearOutEvents(Blinky4* handle);

const sc_integer BLINKY4_BLINKY4INTERNAL_TICSON = 50;
const sc_integer BLINKY4_BLINKY4INTERNAL_TICSOFF = 150;
const sc_integer BLINKY4_BLINKY4INTERNAL_TICSDEB = 20;

void blinky4_init(Blinky4* handle)
{
	sc_integer i;

	for (i = 0; i < BLINKY4_MAX_ORTHOGONAL_STATES; ++i)
	{
		handle->stateConfVector[i] = Blinky4_last_state;
	}
	
	
	handle->stateConfVectorPosition = 0;

	blinky4_clearInEvents(handle);
	blinky4_clearOutEvents(handle);

	/* Default init sequence for statechart blinky4 */
	handle->iface.bPulsador = bool_false;
	handle->internal.tics = 0;
	handle->internal.dtics = 0;

}

void blinky4_enter(Blinky4* handle)
{
	/* Default enter sequence for statechart blinky4 */
	blinky4_enseq_main_region_default(handle);
}

void blinky4_exit(Blinky4* handle)
{
	/* Default exit sequence for statechart blinky4 */
	blinky4_exseq_main_region(handle);
}

sc_boolean blinky4_isActive(const Blinky4* handle)
{
	sc_boolean result;
	if (handle->stateConfVector[0] != Blinky4_last_state || handle->stateConfVector[1] != Blinky4_last_state)
	{
		result =  bool_true;
	}
	else
	{
		result = bool_false;
	}
	return result;
}

/* 
 * Always returns 'false' since this state machine can never become final.
 */
sc_boolean blinky4_isFinal(const Blinky4* handle)
{
   return bool_false;
}

static void blinky4_clearInEvents(Blinky4* handle)
{
	handle->iface.eTics_raised = bool_false;
	handle->internal.eBoton_raised = bool_false;
}

static void blinky4_clearOutEvents(Blinky4* handle)
{
}

void blinky4_runCycle(Blinky4* handle)
{
	
	blinky4_clearOutEvents(handle);
	
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < BLINKY4_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case Blinky4_main_region_Programa_r1_Presionado :
		{
			blinky4_react_main_region_Programa_r1_Presionado(handle);
			break;
		}
		case Blinky4_main_region_Programa_r1_Espera :
		{
			blinky4_react_main_region_Programa_r1_Espera(handle);
			break;
		}
		case Blinky4_main_region_Programa_r1_Presiona :
		{
			blinky4_react_main_region_Programa_r1_Presiona(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn :
		{
			blinky4_react_main_region_Programa_r2_Parpadea_r1_LedOn(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff :
		{
			blinky4_react_main_region_Programa_r2_Parpadea_r1_LedOff(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_No_parpadea :
		{
			blinky4_react_main_region_Programa_r2_No_parpadea(handle);
			break;
		}
		default:
			break;
		}
	}
	
	blinky4_clearInEvents(handle);
}


sc_boolean blinky4_isStateActive(const Blinky4* handle, Blinky4States state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case Blinky4_main_region_Programa :
			result = (sc_boolean) (handle->stateConfVector[0] >= Blinky4_main_region_Programa
				&& handle->stateConfVector[0] <= Blinky4_main_region_Programa_r2_No_parpadea);
			break;
		case Blinky4_main_region_Programa_r1_Presionado :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky4_main_region_Programa_r1_Presionado
			);
			break;
		case Blinky4_main_region_Programa_r1_Espera :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky4_main_region_Programa_r1_Espera
			);
			break;
		case Blinky4_main_region_Programa_r1_Presiona :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky4_main_region_Programa_r1_Presiona
			);
			break;
		case Blinky4_main_region_Programa_r2_Parpadea :
			result = (sc_boolean) (handle->stateConfVector[1] >= Blinky4_main_region_Programa_r2_Parpadea
				&& handle->stateConfVector[1] <= Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff);
			break;
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn :
			result = (sc_boolean) (handle->stateConfVector[1] == Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn
			);
			break;
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff :
			result = (sc_boolean) (handle->stateConfVector[1] == Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff
			);
			break;
		case Blinky4_main_region_Programa_r2_No_parpadea :
			result = (sc_boolean) (handle->stateConfVector[1] == Blinky4_main_region_Programa_r2_No_parpadea
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}

void blinky4Iface_raise_eTics(Blinky4* handle)
{
	handle->iface.eTics_raised = bool_true;
}


sc_boolean blinky4Iface_get_bPulsador(const Blinky4* handle)
{
	return handle->iface.bPulsador;
}
void blinky4Iface_set_bPulsador(Blinky4* handle, sc_boolean value)
{
	handle->iface.bPulsador = value;
}

/* implementations of all internal functions */

static sc_boolean blinky4_check_main_region_Programa_r1_Presionado_tr0_tr0(const Blinky4* handle)
{
	return (handle->iface.bPulsador == bool_true) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r1_Presionado_tr1_tr1(const Blinky4* handle)
{
	return (handle->iface.bPulsador == bool_false) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r1_Espera_tr0_tr0(const Blinky4* handle)
{
	return (handle->iface.bPulsador == bool_true) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r1_Presiona_tr0_tr0(const Blinky4* handle)
{
	return ((handle->iface.eTics_raised) && (handle->internal.dtics > 0)) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r1_Presiona_tr1_tr1(const Blinky4* handle)
{
	return (handle->iface.bPulsador == bool_true && handle->internal.dtics == 0) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r1_Presiona_tr2_tr2(const Blinky4* handle)
{
	return (handle->internal.dtics == 0 && handle->iface.bPulsador == bool_false) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_tr0_tr0(const Blinky4* handle)
{
	return handle->internal.eBoton_raised;
}

static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOn_tr0_tr0(const Blinky4* handle)
{
	return ((handle->iface.eTics_raised) && (handle->internal.tics > 0)) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOn_tr1_tr1(const Blinky4* handle)
{
	return (handle->internal.tics == 0) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOff_tr0_tr0(const Blinky4* handle)
{
	return ((handle->iface.eTics_raised) && (handle->internal.tics > 0)) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOff_tr1_tr1(const Blinky4* handle)
{
	return (handle->internal.tics == 0) ? bool_true : bool_false;
}

static sc_boolean blinky4_check_main_region_Programa_r2_No_parpadea_tr0_tr0(const Blinky4* handle)
{
	return handle->internal.eBoton_raised;
}

static void blinky4_effect_main_region_Programa_r1_Presionado_tr0(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r1_Presionado(handle);
	blinky4_enseq_main_region_Programa_r1_Presionado_default(handle);
}

static void blinky4_effect_main_region_Programa_r1_Presionado_tr1(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r1_Presionado(handle);
	blinky4_enseq_main_region_Programa_r1_Espera_default(handle);
}

static void blinky4_effect_main_region_Programa_r1_Espera_tr0(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r1_Espera(handle);
	handle->internal.dtics = BLINKY4_BLINKY4INTERNAL_TICSDEB;
	blinky4_enseq_main_region_Programa_r1_Presiona_default(handle);
}

static void blinky4_effect_main_region_Programa_r1_Presiona_tr0(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r1_Presiona(handle);
	handle->internal.dtics -= 1;
	blinky4_enseq_main_region_Programa_r1_Presiona_default(handle);
}

static void blinky4_effect_main_region_Programa_r1_Presiona_tr1(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r1_Presiona(handle);
	handle->internal.eBoton_raised = bool_true;
	blinky4_enseq_main_region_Programa_r1_Presionado_default(handle);
}

static void blinky4_effect_main_region_Programa_r1_Presiona_tr2(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r1_Presiona(handle);
	blinky4_enseq_main_region_Programa_r1_Espera_default(handle);
}

static void blinky4_effect_main_region_Programa_r2_Parpadea_tr0(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r2_Parpadea(handle);
	blinky4_enseq_main_region_Programa_r2_No_parpadea_default(handle);
}

static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOn_tr0(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOn(handle);
	handle->internal.tics -= 1;
	blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOn_default(handle);
}

static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOn_tr1(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOn(handle);
	handle->internal.tics = BLINKY4_BLINKY4INTERNAL_TICSOFF;
	blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOff_default(handle);
}

static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOff_tr0(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOff(handle);
	handle->internal.tics -= 1;
	blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOff_default(handle);
}

static void blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOff_tr1(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOff(handle);
	handle->internal.tics = BLINKY4_BLINKY4INTERNAL_TICSON;
	blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOn_default(handle);
}

static void blinky4_effect_main_region_Programa_r2_No_parpadea_tr0(Blinky4* handle)
{
	blinky4_exseq_main_region_Programa_r2_No_parpadea(handle);
	blinky4_enseq_main_region_Programa_r2_Parpadea_default(handle);
}

/* Entry action for state 'LedOn'. */
static void blinky4_enact_main_region_Programa_r2_Parpadea_r1_LedOn(Blinky4* handle)
{
	/* Entry action for state 'LedOn'. */
	blinky4Iface_setLed(handle, bool_true);
}

/* Entry action for state 'LedOff'. */
static void blinky4_enact_main_region_Programa_r2_Parpadea_r1_LedOff(Blinky4* handle)
{
	/* Entry action for state 'LedOff'. */
	blinky4Iface_setLed(handle, bool_false);
}

/* Entry action for state 'No parpadea'. */
static void blinky4_enact_main_region_Programa_r2_No_parpadea(Blinky4* handle)
{
	/* Entry action for state 'No parpadea'. */
	blinky4Iface_setLed(handle, bool_false);
}

/* 'default' enter sequence for state Programa */
static void blinky4_enseq_main_region_Programa_default(Blinky4* handle)
{
	/* 'default' enter sequence for state Programa */
	blinky4_enseq_main_region_Programa_r1_default(handle);
	blinky4_enseq_main_region_Programa_r2_default(handle);
}

/* 'default' enter sequence for state Presionado */
static void blinky4_enseq_main_region_Programa_r1_Presionado_default(Blinky4* handle)
{
	/* 'default' enter sequence for state Presionado */
	handle->stateConfVector[0] = Blinky4_main_region_Programa_r1_Presionado;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Espera */
static void blinky4_enseq_main_region_Programa_r1_Espera_default(Blinky4* handle)
{
	/* 'default' enter sequence for state Espera */
	handle->stateConfVector[0] = Blinky4_main_region_Programa_r1_Espera;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Presiona */
static void blinky4_enseq_main_region_Programa_r1_Presiona_default(Blinky4* handle)
{
	/* 'default' enter sequence for state Presiona */
	handle->stateConfVector[0] = Blinky4_main_region_Programa_r1_Presiona;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Parpadea */
static void blinky4_enseq_main_region_Programa_r2_Parpadea_default(Blinky4* handle)
{
	/* 'default' enter sequence for state Parpadea */
	blinky4_enseq_main_region_Programa_r2_Parpadea_r1_default(handle);
}

/* 'default' enter sequence for state LedOn */
static void blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOn_default(Blinky4* handle)
{
	/* 'default' enter sequence for state LedOn */
	blinky4_enact_main_region_Programa_r2_Parpadea_r1_LedOn(handle);
	handle->stateConfVector[1] = Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for state LedOff */
static void blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOff_default(Blinky4* handle)
{
	/* 'default' enter sequence for state LedOff */
	blinky4_enact_main_region_Programa_r2_Parpadea_r1_LedOff(handle);
	handle->stateConfVector[1] = Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for state No parpadea */
static void blinky4_enseq_main_region_Programa_r2_No_parpadea_default(Blinky4* handle)
{
	/* 'default' enter sequence for state No parpadea */
	blinky4_enact_main_region_Programa_r2_No_parpadea(handle);
	handle->stateConfVector[1] = Blinky4_main_region_Programa_r2_No_parpadea;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for region main region */
static void blinky4_enseq_main_region_default(Blinky4* handle)
{
	/* 'default' enter sequence for region main region */
	blinky4_react_main_region__entry_Default(handle);
}

/* 'default' enter sequence for region r1 */
static void blinky4_enseq_main_region_Programa_r1_default(Blinky4* handle)
{
	/* 'default' enter sequence for region r1 */
	blinky4_react_main_region_Programa_r1__entry_Default(handle);
}

/* 'default' enter sequence for region r2 */
static void blinky4_enseq_main_region_Programa_r2_default(Blinky4* handle)
{
	/* 'default' enter sequence for region r2 */
	blinky4_react_main_region_Programa_r2__entry_Default(handle);
}

/* 'default' enter sequence for region r1 */
static void blinky4_enseq_main_region_Programa_r2_Parpadea_r1_default(Blinky4* handle)
{
	/* 'default' enter sequence for region r1 */
	blinky4_react_main_region_Programa_r2_Parpadea_r1__entry_Default(handle);
}

/* Default exit sequence for state Presionado */
static void blinky4_exseq_main_region_Programa_r1_Presionado(Blinky4* handle)
{
	/* Default exit sequence for state Presionado */
	handle->stateConfVector[0] = Blinky4_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Espera */
static void blinky4_exseq_main_region_Programa_r1_Espera(Blinky4* handle)
{
	/* Default exit sequence for state Espera */
	handle->stateConfVector[0] = Blinky4_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Presiona */
static void blinky4_exseq_main_region_Programa_r1_Presiona(Blinky4* handle)
{
	/* Default exit sequence for state Presiona */
	handle->stateConfVector[0] = Blinky4_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Parpadea */
static void blinky4_exseq_main_region_Programa_r2_Parpadea(Blinky4* handle)
{
	/* Default exit sequence for state Parpadea */
	blinky4_exseq_main_region_Programa_r2_Parpadea_r1(handle);
}

/* Default exit sequence for state LedOn */
static void blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOn(Blinky4* handle)
{
	/* Default exit sequence for state LedOn */
	handle->stateConfVector[1] = Blinky4_last_state;
	handle->stateConfVectorPosition = 1;
}

/* Default exit sequence for state LedOff */
static void blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOff(Blinky4* handle)
{
	/* Default exit sequence for state LedOff */
	handle->stateConfVector[1] = Blinky4_last_state;
	handle->stateConfVectorPosition = 1;
}

/* Default exit sequence for state No parpadea */
static void blinky4_exseq_main_region_Programa_r2_No_parpadea(Blinky4* handle)
{
	/* Default exit sequence for state No parpadea */
	handle->stateConfVector[1] = Blinky4_last_state;
	handle->stateConfVectorPosition = 1;
}

/* Default exit sequence for region main region */
static void blinky4_exseq_main_region(Blinky4* handle)
{
	/* Default exit sequence for region main region */
	/* Handle exit of all possible states (of blinky4.main_region) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Blinky4_main_region_Programa_r1_Presionado :
		{
			blinky4_exseq_main_region_Programa_r1_Presionado(handle);
			break;
		}
		case Blinky4_main_region_Programa_r1_Espera :
		{
			blinky4_exseq_main_region_Programa_r1_Espera(handle);
			break;
		}
		case Blinky4_main_region_Programa_r1_Presiona :
		{
			blinky4_exseq_main_region_Programa_r1_Presiona(handle);
			break;
		}
		default: break;
	}
	/* Handle exit of all possible states (of blinky4.main_region) at position 1... */
	switch(handle->stateConfVector[ 1 ])
	{
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn :
		{
			blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOn(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff :
		{
			blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOff(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_No_parpadea :
		{
			blinky4_exseq_main_region_Programa_r2_No_parpadea(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region r1 */
static void blinky4_exseq_main_region_Programa_r1(Blinky4* handle)
{
	/* Default exit sequence for region r1 */
	/* Handle exit of all possible states (of blinky4.main_region.Programa.r1) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Blinky4_main_region_Programa_r1_Presionado :
		{
			blinky4_exseq_main_region_Programa_r1_Presionado(handle);
			break;
		}
		case Blinky4_main_region_Programa_r1_Espera :
		{
			blinky4_exseq_main_region_Programa_r1_Espera(handle);
			break;
		}
		case Blinky4_main_region_Programa_r1_Presiona :
		{
			blinky4_exseq_main_region_Programa_r1_Presiona(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region r2 */
static void blinky4_exseq_main_region_Programa_r2(Blinky4* handle)
{
	/* Default exit sequence for region r2 */
	/* Handle exit of all possible states (of blinky4.main_region.Programa.r2) at position 1... */
	switch(handle->stateConfVector[ 1 ])
	{
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn :
		{
			blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOn(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff :
		{
			blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOff(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_No_parpadea :
		{
			blinky4_exseq_main_region_Programa_r2_No_parpadea(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region r1 */
static void blinky4_exseq_main_region_Programa_r2_Parpadea_r1(Blinky4* handle)
{
	/* Default exit sequence for region r1 */
	/* Handle exit of all possible states (of blinky4.main_region.Programa.r2.Parpadea.r1) at position 1... */
	switch(handle->stateConfVector[ 1 ])
	{
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn :
		{
			blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOn(handle);
			break;
		}
		case Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff :
		{
			blinky4_exseq_main_region_Programa_r2_Parpadea_r1_LedOff(handle);
			break;
		}
		default: break;
	}
}

/* The reactions of state Presionado. */
static void blinky4_react_main_region_Programa_r1_Presionado(Blinky4* handle)
{
	/* The reactions of state Presionado. */
	if (blinky4_check_main_region_Programa_r1_Presionado_tr0_tr0(handle) == bool_true)
	{ 
		blinky4_effect_main_region_Programa_r1_Presionado_tr0(handle);
	}  else
	{
		if (blinky4_check_main_region_Programa_r1_Presionado_tr1_tr1(handle) == bool_true)
		{ 
			blinky4_effect_main_region_Programa_r1_Presionado_tr1(handle);
		} 
	}
}

/* The reactions of state Espera. */
static void blinky4_react_main_region_Programa_r1_Espera(Blinky4* handle)
{
	/* The reactions of state Espera. */
	if (blinky4_check_main_region_Programa_r1_Espera_tr0_tr0(handle) == bool_true)
	{ 
		blinky4_effect_main_region_Programa_r1_Espera_tr0(handle);
	} 
}

/* The reactions of state Presiona. */
static void blinky4_react_main_region_Programa_r1_Presiona(Blinky4* handle)
{
	/* The reactions of state Presiona. */
	if (blinky4_check_main_region_Programa_r1_Presiona_tr0_tr0(handle) == bool_true)
	{ 
		blinky4_effect_main_region_Programa_r1_Presiona_tr0(handle);
	}  else
	{
		if (blinky4_check_main_region_Programa_r1_Presiona_tr1_tr1(handle) == bool_true)
		{ 
			blinky4_effect_main_region_Programa_r1_Presiona_tr1(handle);
		}  else
		{
			if (blinky4_check_main_region_Programa_r1_Presiona_tr2_tr2(handle) == bool_true)
			{ 
				blinky4_effect_main_region_Programa_r1_Presiona_tr2(handle);
			} 
		}
	}
}

/* The reactions of state LedOn. */
static void blinky4_react_main_region_Programa_r2_Parpadea_r1_LedOn(Blinky4* handle)
{
	/* The reactions of state LedOn. */
	if (blinky4_check_main_region_Programa_r2_Parpadea_tr0_tr0(handle) == bool_true)
	{ 
		blinky4_effect_main_region_Programa_r2_Parpadea_tr0(handle);
	}  else
	{
		if (blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOn_tr0_tr0(handle) == bool_true)
		{ 
			blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOn_tr0(handle);
		}  else
		{
			if (blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOn_tr1_tr1(handle) == bool_true)
			{ 
				blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOn_tr1(handle);
			} 
		}
	}
}

/* The reactions of state LedOff. */
static void blinky4_react_main_region_Programa_r2_Parpadea_r1_LedOff(Blinky4* handle)
{
	/* The reactions of state LedOff. */
	if (blinky4_check_main_region_Programa_r2_Parpadea_tr0_tr0(handle) == bool_true)
	{ 
		blinky4_effect_main_region_Programa_r2_Parpadea_tr0(handle);
	}  else
	{
		if (blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOff_tr0_tr0(handle) == bool_true)
		{ 
			blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOff_tr0(handle);
		}  else
		{
			if (blinky4_check_main_region_Programa_r2_Parpadea_r1_LedOff_tr1_tr1(handle) == bool_true)
			{ 
				blinky4_effect_main_region_Programa_r2_Parpadea_r1_LedOff_tr1(handle);
			} 
		}
	}
}

/* The reactions of state No parpadea. */
static void blinky4_react_main_region_Programa_r2_No_parpadea(Blinky4* handle)
{
	/* The reactions of state No parpadea. */
	if (blinky4_check_main_region_Programa_r2_No_parpadea_tr0_tr0(handle) == bool_true)
	{ 
		blinky4_effect_main_region_Programa_r2_No_parpadea_tr0(handle);
	} 
}

/* Default react sequence for initial entry  */
static void blinky4_react_main_region__entry_Default(Blinky4* handle)
{
	/* Default react sequence for initial entry  */
	blinky4_enseq_main_region_Programa_default(handle);
}

/* Default react sequence for initial entry  */
static void blinky4_react_main_region_Programa_r1__entry_Default(Blinky4* handle)
{
	/* Default react sequence for initial entry  */
	blinky4_enseq_main_region_Programa_r1_Espera_default(handle);
}

/* Default react sequence for initial entry  */
static void blinky4_react_main_region_Programa_r2_Parpadea_r1__entry_Default(Blinky4* handle)
{
	/* Default react sequence for initial entry  */
	handle->internal.tics = BLINKY4_BLINKY4INTERNAL_TICSON;
	blinky4_enseq_main_region_Programa_r2_Parpadea_r1_LedOn_default(handle);
}

/* Default react sequence for initial entry  */
static void blinky4_react_main_region_Programa_r2__entry_Default(Blinky4* handle)
{
	/* Default react sequence for initial entry  */
	blinky4_enseq_main_region_Programa_r2_Parpadea_default(handle);
}


