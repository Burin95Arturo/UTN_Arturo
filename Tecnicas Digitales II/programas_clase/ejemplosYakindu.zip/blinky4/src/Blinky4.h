
#ifndef BLINKY4_H_
#define BLINKY4_H_

#include "../fsm/src/sc_types.h"
		
#ifdef __cplusplus
extern "C" { 
#endif 

/*! \file Header of the state machine 'blinky4'.
*/

/*! Enumeration of all states */ 
typedef enum
{
	Blinky4_main_region_Programa,
	Blinky4_main_region_Programa_r1_Presionado,
	Blinky4_main_region_Programa_r1_Espera,
	Blinky4_main_region_Programa_r1_Presiona,
	Blinky4_main_region_Programa_r2_Parpadea,
	Blinky4_main_region_Programa_r2_Parpadea_r1_LedOn,
	Blinky4_main_region_Programa_r2_Parpadea_r1_LedOff,
	Blinky4_main_region_Programa_r2_No_parpadea,
	Blinky4_last_state
} Blinky4States;

/*! Type definition of the data structure for the Blinky4Iface interface scope. */
typedef struct
{
	sc_boolean eTics_raised;
	sc_boolean bPulsador;
} Blinky4Iface;

/*! Type definition of the data structure for the Blinky4Internal interface scope. */
typedef struct
{
	sc_integer tics;
	sc_boolean eBoton_raised;
	sc_integer dtics;
} Blinky4Internal;


/*! Define dimension of the state configuration vector for orthogonal states. */
#define BLINKY4_MAX_ORTHOGONAL_STATES 2

/*! 
 * Type definition of the data structure for the Blinky4 state machine.
 * This data structure has to be allocated by the client code. 
 */
typedef struct
{
	Blinky4States stateConfVector[BLINKY4_MAX_ORTHOGONAL_STATES];
	sc_ushort stateConfVectorPosition; 
	
	Blinky4Iface iface;
	Blinky4Internal internal;
} Blinky4;

/*! Initializes the Blinky4 state machine data structures. Must be called before first usage.*/
extern void blinky4_init(Blinky4* handle);

/*! Activates the state machine */
extern void blinky4_enter(Blinky4* handle);

/*! Deactivates the state machine */
extern void blinky4_exit(Blinky4* handle);

/*! Performs a 'run to completion' step. */
extern void blinky4_runCycle(Blinky4* handle);


/*! Raises the in event 'eTics' that is defined in the default interface scope. */ 
extern void blinky4Iface_raise_eTics(Blinky4* handle);

/*! Gets the value of the variable 'bPulsador' that is defined in the default interface scope. */ 
extern sc_boolean blinky4Iface_get_bPulsador(const Blinky4* handle);
/*! Sets the value of the variable 'bPulsador' that is defined in the default interface scope. */ 
extern void blinky4Iface_set_bPulsador(Blinky4* handle, sc_boolean value);

/*!
 * Checks whether the state machine is active (until 2.4.1 this method was used for states).
 * A state machine is active if it was entered. It is inactive if it has not been entered at all or if it has been exited.
 */
extern sc_boolean blinky4_isActive(const Blinky4* handle);

/*!
 * Checks if all active states are final. 
 * If there are no active states then the state machine is considered being inactive. In this case this method returns false.
 */
extern sc_boolean blinky4_isFinal(const Blinky4* handle);

/*! Checks if the specified state is active (until 2.4.1 the used method for states was called isActive()). */
extern sc_boolean blinky4_isStateActive(const Blinky4* handle, Blinky4States state);

#ifdef __cplusplus
}
#endif 

#endif /* BLINKY4_H_ */
