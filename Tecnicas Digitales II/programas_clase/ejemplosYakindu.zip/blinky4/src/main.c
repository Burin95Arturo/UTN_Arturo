#include "main.h"
#include "board.h"
#include "pulsadores.h"
#include "Blinky4.h"
#include "Blinky4Required.h"

Blinky4 bestado;

void blinky4Iface_setLed(const Blinky4* handle, const sc_boolean estado)
{
	Board_LED_Set(0,estado);
}

static void initHardware(void)
{
	Board_Init();
	InitPulsadores();
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock / 1000);

}

int main(void)
{
	blinky4_init(&bestado);
	blinky4_enter(&bestado);
	initHardware();

	while (1)
	{
			blinky4Iface_set_bPulsador(&bestado, !LeerPulsador(0));
			blinky4_runCycle(&bestado);
			__WFI();
	}
}

void SysTick_Handler(void)
{
	blinky4Iface_raise_eTics(&bestado);
}
