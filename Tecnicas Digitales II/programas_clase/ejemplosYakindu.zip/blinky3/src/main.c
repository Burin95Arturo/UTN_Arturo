#include "main.h"
#include "board.h"
#include "Blinky3.h"
#include "Blinky3Required.h"
#define  NESTADOS 4

Blinky3 bestado[NESTADOS];
int eventoTic;

void blinky3Iface_setLed(const Blinky3* handle, const sc_boolean estado)
{
	int i;
	for(i=0;i<NESTADOS; i++)
	{
		if(handle==&bestado[i])
		{
			Board_LED_Set(i+2,estado); break;
		}
	}
}

static void initHardware(void)
{
	Board_Init();
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock / 1000);
}

int main(void)
{
	int i;
	eventoTic = 0;
	for(i=0;i<NESTADOS; i++)
	{
		blinky3_init(&bestado[i]);
		blinky3_enter(&bestado[i]);
	}
	initHardware();

	while (1)
	{
		if(eventoTic)
		{
			eventoTic = 0;
			for(i=0;i<NESTADOS; i++)
			{
				blinky3Iface_raise_eTics(&bestado[i]);
				blinky3_runCycle(&bestado[i]);
			}
		}
		__WFI();
	}
}

void SysTick_Handler(void)
{
	eventoTic = 1;
}
