
#include <stdlib.h>
#include <string.h>
#include "../fsm/src/sc_types.h"
#include "Blinky3.h"
#include "Blinky3Required.h"
/*! \file Implementation of the state machine 'blinky3'
*/

/* prototypes of all internal functions */
static sc_boolean blinky3_check_main_region_LedOn_tr0_tr0(const Blinky3* handle);
static sc_boolean blinky3_check_main_region_LedOn_tr1_tr1(const Blinky3* handle);
static sc_boolean blinky3_check_main_region_LedOff_tr0_tr0(const Blinky3* handle);
static sc_boolean blinky3_check_main_region_LedOff_tr1_tr1(const Blinky3* handle);
static void blinky3_effect_main_region_LedOn_tr0(Blinky3* handle);
static void blinky3_effect_main_region_LedOn_tr1(Blinky3* handle);
static void blinky3_effect_main_region_LedOff_tr0(Blinky3* handle);
static void blinky3_effect_main_region_LedOff_tr1(Blinky3* handle);
static void blinky3_enact_main_region_LedOn(Blinky3* handle);
static void blinky3_enact_main_region_LedOff(Blinky3* handle);
static void blinky3_enseq_main_region_LedOn_default(Blinky3* handle);
static void blinky3_enseq_main_region_LedOff_default(Blinky3* handle);
static void blinky3_enseq_main_region_default(Blinky3* handle);
static void blinky3_exseq_main_region_LedOn(Blinky3* handle);
static void blinky3_exseq_main_region_LedOff(Blinky3* handle);
static void blinky3_exseq_main_region(Blinky3* handle);
static void blinky3_react_main_region_LedOn(Blinky3* handle);
static void blinky3_react_main_region_LedOff(Blinky3* handle);
static void blinky3_react_main_region__entry_Default(Blinky3* handle);
static void blinky3_clearInEvents(Blinky3* handle);
static void blinky3_clearOutEvents(Blinky3* handle);

const sc_integer BLINKY3_BLINKY3INTERNAL_TICSON = 250;
const sc_integer BLINKY3_BLINKY3INTERNAL_TICSOFF = 250;

void blinky3_init(Blinky3* handle)
{
	sc_integer i;

	for (i = 0; i < BLINKY3_MAX_ORTHOGONAL_STATES; ++i)
	{
		handle->stateConfVector[i] = Blinky3_last_state;
	}
	
	
	handle->stateConfVectorPosition = 0;

	blinky3_clearInEvents(handle);
	blinky3_clearOutEvents(handle);

	/* Default init sequence for statechart blinky3 */
	handle->internal.tics = 0;

}

void blinky3_enter(Blinky3* handle)
{
	/* Default enter sequence for statechart blinky3 */
	blinky3_enseq_main_region_default(handle);
}

void blinky3_exit(Blinky3* handle)
{
	/* Default exit sequence for statechart blinky3 */
	blinky3_exseq_main_region(handle);
}

sc_boolean blinky3_isActive(const Blinky3* handle)
{
	sc_boolean result;
	if (handle->stateConfVector[0] != Blinky3_last_state)
	{
		result =  bool_true;
	}
	else
	{
		result = bool_false;
	}
	return result;
}

/* 
 * Always returns 'false' since this state machine can never become final.
 */
sc_boolean blinky3_isFinal(const Blinky3* handle)
{
   return bool_false;
}

static void blinky3_clearInEvents(Blinky3* handle)
{
	handle->iface.eTics_raised = bool_false;
}

static void blinky3_clearOutEvents(Blinky3* handle)
{
}

void blinky3_runCycle(Blinky3* handle)
{
	
	blinky3_clearOutEvents(handle);
	
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < BLINKY3_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case Blinky3_main_region_LedOn :
		{
			blinky3_react_main_region_LedOn(handle);
			break;
		}
		case Blinky3_main_region_LedOff :
		{
			blinky3_react_main_region_LedOff(handle);
			break;
		}
		default:
			break;
		}
	}
	
	blinky3_clearInEvents(handle);
}


sc_boolean blinky3_isStateActive(const Blinky3* handle, Blinky3States state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case Blinky3_main_region_LedOn :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky3_main_region_LedOn
			);
			break;
		case Blinky3_main_region_LedOff :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky3_main_region_LedOff
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}

void blinky3Iface_raise_eTics(Blinky3* handle)
{
	handle->iface.eTics_raised = bool_true;
}



/* implementations of all internal functions */

static sc_boolean blinky3_check_main_region_LedOn_tr0_tr0(const Blinky3* handle)
{
	return ((handle->iface.eTics_raised) && (handle->internal.tics > 0)) ? bool_true : bool_false;
}

static sc_boolean blinky3_check_main_region_LedOn_tr1_tr1(const Blinky3* handle)
{
	return (handle->internal.tics == 0) ? bool_true : bool_false;
}

static sc_boolean blinky3_check_main_region_LedOff_tr0_tr0(const Blinky3* handle)
{
	return ((handle->iface.eTics_raised) && (handle->internal.tics > 0)) ? bool_true : bool_false;
}

static sc_boolean blinky3_check_main_region_LedOff_tr1_tr1(const Blinky3* handle)
{
	return (handle->internal.tics == 0) ? bool_true : bool_false;
}

static void blinky3_effect_main_region_LedOn_tr0(Blinky3* handle)
{
	blinky3_exseq_main_region_LedOn(handle);
	handle->internal.tics -= 1;
	blinky3_enseq_main_region_LedOn_default(handle);
}

static void blinky3_effect_main_region_LedOn_tr1(Blinky3* handle)
{
	blinky3_exseq_main_region_LedOn(handle);
	handle->internal.tics = BLINKY3_BLINKY3INTERNAL_TICSOFF;
	blinky3_enseq_main_region_LedOff_default(handle);
}

static void blinky3_effect_main_region_LedOff_tr0(Blinky3* handle)
{
	blinky3_exseq_main_region_LedOff(handle);
	handle->internal.tics -= 1;
	blinky3_enseq_main_region_LedOff_default(handle);
}

static void blinky3_effect_main_region_LedOff_tr1(Blinky3* handle)
{
	blinky3_exseq_main_region_LedOff(handle);
	handle->internal.tics = BLINKY3_BLINKY3INTERNAL_TICSON;
	blinky3_enseq_main_region_LedOn_default(handle);
}

/* Entry action for state 'LedOn'. */
static void blinky3_enact_main_region_LedOn(Blinky3* handle)
{
	/* Entry action for state 'LedOn'. */
	blinky3Iface_setLed(handle, bool_true);
}

/* Entry action for state 'LedOff'. */
static void blinky3_enact_main_region_LedOff(Blinky3* handle)
{
	/* Entry action for state 'LedOff'. */
	blinky3Iface_setLed(handle, bool_false);
}

/* 'default' enter sequence for state LedOn */
static void blinky3_enseq_main_region_LedOn_default(Blinky3* handle)
{
	/* 'default' enter sequence for state LedOn */
	blinky3_enact_main_region_LedOn(handle);
	handle->stateConfVector[0] = Blinky3_main_region_LedOn;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state LedOff */
static void blinky3_enseq_main_region_LedOff_default(Blinky3* handle)
{
	/* 'default' enter sequence for state LedOff */
	blinky3_enact_main_region_LedOff(handle);
	handle->stateConfVector[0] = Blinky3_main_region_LedOff;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for region main region */
static void blinky3_enseq_main_region_default(Blinky3* handle)
{
	/* 'default' enter sequence for region main region */
	blinky3_react_main_region__entry_Default(handle);
}

/* Default exit sequence for state LedOn */
static void blinky3_exseq_main_region_LedOn(Blinky3* handle)
{
	/* Default exit sequence for state LedOn */
	handle->stateConfVector[0] = Blinky3_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state LedOff */
static void blinky3_exseq_main_region_LedOff(Blinky3* handle)
{
	/* Default exit sequence for state LedOff */
	handle->stateConfVector[0] = Blinky3_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for region main region */
static void blinky3_exseq_main_region(Blinky3* handle)
{
	/* Default exit sequence for region main region */
	/* Handle exit of all possible states (of blinky3.main_region) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Blinky3_main_region_LedOn :
		{
			blinky3_exseq_main_region_LedOn(handle);
			break;
		}
		case Blinky3_main_region_LedOff :
		{
			blinky3_exseq_main_region_LedOff(handle);
			break;
		}
		default: break;
	}
}

/* The reactions of state LedOn. */
static void blinky3_react_main_region_LedOn(Blinky3* handle)
{
	/* The reactions of state LedOn. */
	if (blinky3_check_main_region_LedOn_tr0_tr0(handle) == bool_true)
	{ 
		blinky3_effect_main_region_LedOn_tr0(handle);
	}  else
	{
		if (blinky3_check_main_region_LedOn_tr1_tr1(handle) == bool_true)
		{ 
			blinky3_effect_main_region_LedOn_tr1(handle);
		} 
	}
}

/* The reactions of state LedOff. */
static void blinky3_react_main_region_LedOff(Blinky3* handle)
{
	/* The reactions of state LedOff. */
	if (blinky3_check_main_region_LedOff_tr0_tr0(handle) == bool_true)
	{ 
		blinky3_effect_main_region_LedOff_tr0(handle);
	}  else
	{
		if (blinky3_check_main_region_LedOff_tr1_tr1(handle) == bool_true)
		{ 
			blinky3_effect_main_region_LedOff_tr1(handle);
		} 
	}
}

/* Default react sequence for initial entry  */
static void blinky3_react_main_region__entry_Default(Blinky3* handle)
{
	/* Default react sequence for initial entry  */
	handle->internal.tics = BLINKY3_BLINKY3INTERNAL_TICSON;
	blinky3_enseq_main_region_LedOn_default(handle);
}


