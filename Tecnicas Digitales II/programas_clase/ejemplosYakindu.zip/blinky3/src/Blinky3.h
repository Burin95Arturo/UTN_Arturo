
#ifndef BLINKY3_H_
#define BLINKY3_H_

#include "../fsm/src/sc_types.h"
		
#ifdef __cplusplus
extern "C" { 
#endif 

/*! \file Header of the state machine 'blinky3'.
*/

/*! Enumeration of all states */ 
typedef enum
{
	Blinky3_main_region_LedOn,
	Blinky3_main_region_LedOff,
	Blinky3_last_state
} Blinky3States;

/*! Type definition of the data structure for the Blinky3Iface interface scope. */
typedef struct
{
	sc_boolean eTics_raised;
} Blinky3Iface;

/*! Type definition of the data structure for the Blinky3Internal interface scope. */
typedef struct
{
	sc_integer tics;
} Blinky3Internal;


/*! Define dimension of the state configuration vector for orthogonal states. */
#define BLINKY3_MAX_ORTHOGONAL_STATES 1

/*! 
 * Type definition of the data structure for the Blinky3 state machine.
 * This data structure has to be allocated by the client code. 
 */
typedef struct
{
	Blinky3States stateConfVector[BLINKY3_MAX_ORTHOGONAL_STATES];
	sc_ushort stateConfVectorPosition; 
	
	Blinky3Iface iface;
	Blinky3Internal internal;
} Blinky3;

/*! Initializes the Blinky3 state machine data structures. Must be called before first usage.*/
extern void blinky3_init(Blinky3* handle);

/*! Activates the state machine */
extern void blinky3_enter(Blinky3* handle);

/*! Deactivates the state machine */
extern void blinky3_exit(Blinky3* handle);

/*! Performs a 'run to completion' step. */
extern void blinky3_runCycle(Blinky3* handle);


/*! Raises the in event 'eTics' that is defined in the default interface scope. */ 
extern void blinky3Iface_raise_eTics(Blinky3* handle);


/*!
 * Checks whether the state machine is active (until 2.4.1 this method was used for states).
 * A state machine is active if it was entered. It is inactive if it has not been entered at all or if it has been exited.
 */
extern sc_boolean blinky3_isActive(const Blinky3* handle);

/*!
 * Checks if all active states are final. 
 * If there are no active states then the state machine is considered being inactive. In this case this method returns false.
 */
extern sc_boolean blinky3_isFinal(const Blinky3* handle);

/*! Checks if the specified state is active (until 2.4.1 the used method for states was called isActive()). */
extern sc_boolean blinky3_isStateActive(const Blinky3* handle, Blinky3States state);

#ifdef __cplusplus
}
#endif 

#endif /* BLINKY3_H_ */
