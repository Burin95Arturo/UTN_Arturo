
#ifndef BLINKY3REQUIRED_H_
#define BLINKY3REQUIRED_H_

#include "../fsm/src/sc_types.h"
#include "Blinky3.h"

#ifdef __cplusplus
extern "C"
{
#endif 

/*! \file This header defines prototypes for all functions that are required by the state machine implementation.

This state machine makes use of operations declared in the state machines interface or internal scopes. Thus the function prototypes:
	- blinky3Iface_setLed
are defined.

These functions will be called during a 'run to completion step' (runCycle) of the statechart. 
There are some constraints that have to be considered for the implementation of these functions:
	- never call the statechart API functions from within these functions.
	- make sure that the execution time is as short as possible.
 
*/
extern void blinky3Iface_setLed(const Blinky3* handle, const sc_boolean estado);





#ifdef __cplusplus
}
#endif 

#endif /* BLINKY3REQUIRED_H_ */
