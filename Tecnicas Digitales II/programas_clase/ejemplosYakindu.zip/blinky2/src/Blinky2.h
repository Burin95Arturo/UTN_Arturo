
#ifndef BLINKY2_H_
#define BLINKY2_H_

#include "../fsm/src/sc_types.h"
		
#ifdef __cplusplus
extern "C" { 
#endif 

/*! \file Header of the state machine 'blinky2'.
*/

/*! Enumeration of all states */ 
typedef enum
{
	Blinky2_eT_LedOn,
	Blinky2_eT_LedOff,
	Blinky2_last_state
} Blinky2States;

/*! Type definition of the data structure for the Blinky2Internal interface scope. */
typedef struct
{
	sc_boolean eTics_raised;
} Blinky2Internal;

/*! Type definition of the data structure for the Blinky2TimeEvents interface scope. */
typedef struct
{
	sc_boolean blinky2_tev0_raised;
} Blinky2TimeEvents;


/*! Define dimension of the state configuration vector for orthogonal states. */
#define BLINKY2_MAX_ORTHOGONAL_STATES 1

/*! 
 * Type definition of the data structure for the Blinky2 state machine.
 * This data structure has to be allocated by the client code. 
 */
typedef struct
{
	Blinky2States stateConfVector[BLINKY2_MAX_ORTHOGONAL_STATES];
	sc_ushort stateConfVectorPosition; 
	
	Blinky2Internal internal;
	Blinky2TimeEvents timeEvents;
} Blinky2;

/*! Initializes the Blinky2 state machine data structures. Must be called before first usage.*/
extern void blinky2_init(Blinky2* handle);

/*! Activates the state machine */
extern void blinky2_enter(Blinky2* handle);

/*! Deactivates the state machine */
extern void blinky2_exit(Blinky2* handle);

/*! Performs a 'run to completion' step. */
extern void blinky2_runCycle(Blinky2* handle);

/*! Raises a time event. */
extern void blinky2_raiseTimeEvent(const Blinky2* handle, sc_eventid evid);


/*!
 * Checks whether the state machine is active (until 2.4.1 this method was used for states).
 * A state machine is active if it was entered. It is inactive if it has not been entered at all or if it has been exited.
 */
extern sc_boolean blinky2_isActive(const Blinky2* handle);

/*!
 * Checks if all active states are final. 
 * If there are no active states then the state machine is considered being inactive. In this case this method returns false.
 */
extern sc_boolean blinky2_isFinal(const Blinky2* handle);

/*! Checks if the specified state is active (until 2.4.1 the used method for states was called isActive()). */
extern sc_boolean blinky2_isStateActive(const Blinky2* handle, Blinky2States state);

#ifdef __cplusplus
}
#endif 

#endif /* BLINKY2_H_ */
