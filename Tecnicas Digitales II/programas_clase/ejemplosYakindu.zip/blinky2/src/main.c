#include "main.h"
#include "board.h"
#include "Blinky2.h"
#include "Blinky2Required.h"

typedef struct
{
	int tiempo;
	int cuenta;
	sc_eventid id;
	bool periodico;
}TimerTics;

TimerTics tics;
Blinky2 bestado;

void blinky2Iface_setearLed(const Blinky2* handle, const sc_boolean estado)
{
	Board_LED_Set(0,estado);
}

void blinky2_setTimer(Blinky2* handle, const sc_eventid evid, const sc_integer time_ms, const sc_boolean periodic)
{
	tics.id=evid;
	tics.cuenta=0;
	tics.tiempo=time_ms;
	tics.periodico=periodic;
}

void blinky2_unsetTimer(Blinky2* handle, const sc_eventid evid)
{
	tics.id=evid;
	tics.periodico=false;
	tics.tiempo=0;
}

static void initHardware(void)
{
	Board_Init();
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock / 1000);
}

int main(void)
{
	blinky2_init(&bestado);
	blinky2_enter(&bestado);
	initHardware();

	while (1)
	{
			blinky2_runCycle(&bestado);
	}
}

void SysTick_Handler(void)
{
	if(tics.tiempo)
	{
		if(!--tics.cuenta)
		{
			if(tics.periodico) tics.cuenta=tics.tiempo;
			blinky2_raiseTimeEvent(&bestado,tics.id);
		}
	}
}
