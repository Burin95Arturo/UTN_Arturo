
#include <stdlib.h>
#include <string.h>
#include "../fsm/src/sc_types.h"
#include "Blinky2.h"
#include "Blinky2Required.h"
/*! \file Implementation of the state machine 'blinky2'
*/

/* prototypes of all internal functions */
static sc_boolean blinky2_check__lr0(const Blinky2* handle);
static sc_boolean blinky2_check_eT_LedOn_tr0_tr0(const Blinky2* handle);
static sc_boolean blinky2_check_eT_LedOff_tr0_tr0(const Blinky2* handle);
static void blinky2_effect__lr0(Blinky2* handle);
static void blinky2_effect_eT_LedOn_tr0(Blinky2* handle);
static void blinky2_effect_eT_LedOff_tr0(Blinky2* handle);
static void blinky2_enact(Blinky2* handle);
static void blinky2_enact_eT_LedOn(Blinky2* handle);
static void blinky2_enact_eT_LedOff(Blinky2* handle);
static void blinky2_exact(Blinky2* handle);
static void blinky2_enseq_eT_LedOn_default(Blinky2* handle);
static void blinky2_enseq_eT_LedOff_default(Blinky2* handle);
static void blinky2_enseq_eT_default(Blinky2* handle);
static void blinky2_exseq_eT_LedOn(Blinky2* handle);
static void blinky2_exseq_eT_LedOff(Blinky2* handle);
static void blinky2_exseq_eT(Blinky2* handle);
static void blinky2_react_eT_LedOn(Blinky2* handle);
static void blinky2_react_eT_LedOff(Blinky2* handle);
static void blinky2_react_eT__entry_Default(Blinky2* handle);
static void blinky2_clearInEvents(Blinky2* handle);
static void blinky2_clearOutEvents(Blinky2* handle);


void blinky2_init(Blinky2* handle)
{
	sc_integer i;

	for (i = 0; i < BLINKY2_MAX_ORTHOGONAL_STATES; ++i)
	{
		handle->stateConfVector[i] = Blinky2_last_state;
	}
	
	
	handle->stateConfVectorPosition = 0;

	blinky2_clearInEvents(handle);
	blinky2_clearOutEvents(handle);


}

void blinky2_enter(Blinky2* handle)
{
	/* Default enter sequence for statechart blinky2 */
	blinky2_enact(handle);
	blinky2_enseq_eT_default(handle);
}

void blinky2_exit(Blinky2* handle)
{
	/* Default exit sequence for statechart blinky2 */
	blinky2_exseq_eT(handle);
	blinky2_exact(handle);
}

sc_boolean blinky2_isActive(const Blinky2* handle)
{
	sc_boolean result;
	if (handle->stateConfVector[0] != Blinky2_last_state)
	{
		result =  bool_true;
	}
	else
	{
		result = bool_false;
	}
	return result;
}

/* 
 * Always returns 'false' since this state machine can never become final.
 */
sc_boolean blinky2_isFinal(const Blinky2* handle)
{
   return bool_false;
}

static void blinky2_clearInEvents(Blinky2* handle)
{
	handle->internal.eTics_raised = bool_false;
	handle->timeEvents.blinky2_tev0_raised = bool_false;
}

static void blinky2_clearOutEvents(Blinky2* handle)
{
}

void blinky2_runCycle(Blinky2* handle)
{
	
	blinky2_clearOutEvents(handle);
	
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < BLINKY2_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case Blinky2_eT_LedOn :
		{
			blinky2_react_eT_LedOn(handle);
			break;
		}
		case Blinky2_eT_LedOff :
		{
			blinky2_react_eT_LedOff(handle);
			break;
		}
		default:
			break;
		}
	}
	
	blinky2_clearInEvents(handle);
}

void blinky2_raiseTimeEvent(const Blinky2* handle, sc_eventid evid)
{
	if ( ((sc_intptr_t)evid) >= ((sc_intptr_t)&(handle->timeEvents))
		&&  ((sc_intptr_t)evid) < ((sc_intptr_t)&(handle->timeEvents)) + sizeof(Blinky2TimeEvents))
		{
		*(sc_boolean*)evid = bool_true;
	}		
}

sc_boolean blinky2_isStateActive(const Blinky2* handle, Blinky2States state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case Blinky2_eT_LedOn :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky2_eT_LedOn
			);
			break;
		case Blinky2_eT_LedOff :
			result = (sc_boolean) (handle->stateConfVector[0] == Blinky2_eT_LedOff
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}




/* implementations of all internal functions */

static sc_boolean blinky2_check__lr0(const Blinky2* handle)
{
	return handle->timeEvents.blinky2_tev0_raised;
}

static sc_boolean blinky2_check_eT_LedOn_tr0_tr0(const Blinky2* handle)
{
	return handle->internal.eTics_raised;
}

static sc_boolean blinky2_check_eT_LedOff_tr0_tr0(const Blinky2* handle)
{
	return handle->internal.eTics_raised;
}

static void blinky2_effect__lr0(Blinky2* handle)
{
	handle->internal.eTics_raised = bool_true;
}

static void blinky2_effect_eT_LedOn_tr0(Blinky2* handle)
{
	blinky2_exseq_eT_LedOn(handle);
	blinky2_enseq_eT_LedOff_default(handle);
}

static void blinky2_effect_eT_LedOff_tr0(Blinky2* handle)
{
	blinky2_exseq_eT_LedOff(handle);
	blinky2_enseq_eT_LedOn_default(handle);
}

/* Entry action for statechart 'blinky2'. */
static void blinky2_enact(Blinky2* handle)
{
	/* Entry action for statechart 'blinky2'. */
	blinky2_setTimer(handle, (sc_eventid) &(handle->timeEvents.blinky2_tev0_raised) , 125, bool_true);
}

/* Entry action for state 'LedOn'. */
static void blinky2_enact_eT_LedOn(Blinky2* handle)
{
	/* Entry action for state 'LedOn'. */
	blinky2Iface_setearLed(handle, bool_true);
}

/* Entry action for state 'LedOff'. */
static void blinky2_enact_eT_LedOff(Blinky2* handle)
{
	/* Entry action for state 'LedOff'. */
	blinky2Iface_setearLed(handle, bool_false);
}

/* Exit action for state 'blinky2'. */
static void blinky2_exact(Blinky2* handle)
{
	/* Exit action for state 'blinky2'. */
	blinky2_unsetTimer(handle, (sc_eventid) &(handle->timeEvents.blinky2_tev0_raised) );		
}

/* 'default' enter sequence for state LedOn */
static void blinky2_enseq_eT_LedOn_default(Blinky2* handle)
{
	/* 'default' enter sequence for state LedOn */
	blinky2_enact_eT_LedOn(handle);
	handle->stateConfVector[0] = Blinky2_eT_LedOn;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state LedOff */
static void blinky2_enseq_eT_LedOff_default(Blinky2* handle)
{
	/* 'default' enter sequence for state LedOff */
	blinky2_enact_eT_LedOff(handle);
	handle->stateConfVector[0] = Blinky2_eT_LedOff;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for region eT */
static void blinky2_enseq_eT_default(Blinky2* handle)
{
	/* 'default' enter sequence for region eT */
	blinky2_react_eT__entry_Default(handle);
}

/* Default exit sequence for state LedOn */
static void blinky2_exseq_eT_LedOn(Blinky2* handle)
{
	/* Default exit sequence for state LedOn */
	handle->stateConfVector[0] = Blinky2_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state LedOff */
static void blinky2_exseq_eT_LedOff(Blinky2* handle)
{
	/* Default exit sequence for state LedOff */
	handle->stateConfVector[0] = Blinky2_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for region eT */
static void blinky2_exseq_eT(Blinky2* handle)
{
	/* Default exit sequence for region eT */
	/* Handle exit of all possible states (of blinky2.eT) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Blinky2_eT_LedOn :
		{
			blinky2_exseq_eT_LedOn(handle);
			break;
		}
		case Blinky2_eT_LedOff :
		{
			blinky2_exseq_eT_LedOff(handle);
			break;
		}
		default: break;
	}
}

/* The reactions of state LedOn. */
static void blinky2_react_eT_LedOn(Blinky2* handle)
{
	/* The reactions of state LedOn. */
	if (blinky2_check__lr0(handle) == bool_true)
	{ 
		blinky2_effect__lr0(handle);
	} 
	if (blinky2_check_eT_LedOn_tr0_tr0(handle) == bool_true)
	{ 
		blinky2_effect_eT_LedOn_tr0(handle);
	} 
}

/* The reactions of state LedOff. */
static void blinky2_react_eT_LedOff(Blinky2* handle)
{
	/* The reactions of state LedOff. */
	if (blinky2_check__lr0(handle) == bool_true)
	{ 
		blinky2_effect__lr0(handle);
	} 
	if (blinky2_check_eT_LedOff_tr0_tr0(handle) == bool_true)
	{ 
		blinky2_effect_eT_LedOff_tr0(handle);
	} 
}

/* Default react sequence for initial entry  */
static void blinky2_react_eT__entry_Default(Blinky2* handle)
{
	/* Default react sequence for initial entry  */
	blinky2_enseq_eT_LedOn_default(handle);
}


